INTERFACE_TYPE = "interfaceType"
